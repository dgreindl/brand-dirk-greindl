# 🚀 CV Generator – Quick Start Guide

**For: Dirk Greindl**  
**Created: June 16, 2026**

---

## 5-Minute Setup

```bash
# 1. Make sure you're in the cv-generator folder
cd /path/to/cv-generator

# 2. Run setup script (one-time)
bash setup-git.sh

# 3. Generate your first CVs
make generate-all

# 4. Check the results
ls -l output/
```

**Result:** You now have 11 tailored CVs (one for each profile, both Markdown and plain text).

---

## Real-World Usage Scenarios

### Scenario 1: You see a Deloitte Cybersecurity job

**Time: 2 minutes**

```bash
# Step 1: Generate cybersecurity-focused CV
make generate-cyber

# Step 2: View the generated CV
cat output/CV_DirkGreindl_cybersecurity_en.txt

# Step 3: Copy & adapt
# Copy the plain text output
# Paste into Word, adjust minor details
# Save as: "CV_DirkGreindl_Deloitte_2026.docx"
```

**Why this works:** The script already prioritizes Cyber Security standards (ISO/SAE 21434, UN R155/R156) and pushes Automotive-relevant experience to the top.

---

### Scenario 2: You get a job offer and need to update your CV

**Time: 5 minutes**

```bash
# Step 1: Update your master data
vim data/master-cv.json  # or use any editor

# Add new job to "experience" array:
{
  "id": "exp_NEW_001",
  "title": "New Position Title",
  "company": "New Company",
  "location": "City",
  "start_date": "2026-07",
  "current": true,
  "highlights": [
    {
      "text": "Major achievement",
      "details": "What you did and result",
      "tags": ["ISO 26262", "ASIL-D"],
      "priority": 10
    }
  ]
}

# Step 2: Regenerate all CVs
make generate-all

# Step 3: Commit to Git
git add data/master-cv.json
git commit -m "Add: New position at [Company], [date]"

# Step 4: Review generated CVs
cat output/CV_DirkGreindl_safety_manager_en.txt
```

**Result:** All 11 CVs automatically updated with your new job (prioritized appropriately for each profile).

---

### Scenario 3: You want to highlight a new certification

**Time: 3 minutes**

```bash
# Step 1: Edit master-cv.json
# Find "certifications_qualifications" array
# Add: "ISO 27035 (Incident Response & Management)"

# Step 2: Regenerate
make generate-all

# Step 3: Done! All CVs now mention the new cert.
```

---

### Scenario 4: You're applying for a Railway position

**Time: 1 minute**

```bash
# Generate railway-focused CV
make generate-railway

# View
cat output/CV_DirkGreindl_railway_en.txt

# Key differences from other profiles:
# - Highlights EN 50128 / EN 50657 prominently
# - Pushes Alstom & EBA/ERA experience to top
# - Minimizes Aerospace content
```

---

## Command Reference

### Quick Commands

```bash
# Generate all CVs (11 files)
make generate-all

# Generate specific profile only
make generate-safety      # Safety Manager
make generate-cyber       # Cybersecurity
make generate-homologation # Homologation Engineer
make generate-railway     # Railway Expert
make generate-leadership  # Team Leader / Director

# Check Git status
make git-status

# See your commit history
make git-log

# See what changed in your data
make git-diff

# Clean all generated files
make clean

# Show help
make help
```

### Manual Commands (if not using Make)

```bash
# Generate safety manager CV
python3 cv_generator.py --profile safety_manager

# Generate cybersecurity CV in plain text
python3 cv_generator.py --profile cybersecurity --format plaintext

# See all options
python3 cv_generator.py --help
```

---

## File Locations

| File | Purpose | Edit? |
|------|---------|-------|
| `data/master-cv.json` | Your master data | ✅ YES – whenever you update anything |
| `cv_generator.py` | The generator script | ❌ NO – only if adding new features |
| `output/CV_*.txt` | Generated plain text CVs | ❌ NO – regenerate, don't edit |
| `output/CV_*.md` | Generated Markdown CVs | ❌ NO – regenerate, don't edit |
| `.gitignore` | Tells Git to ignore generated files | ⚠️ RARELY |

---

## JSON Data Format – Cheat Sheet

### Adding a New Job

Copy this template and fill in:

```json
{
  "id": "exp_NEW_XXX",
  "title": "Job Title Here",
  "company": "Company Name",
  "location": "City, Country",
  "start_date": "YYYY-MM",
  "end_date": "YYYY-MM",
  "current": false,
  "employment_type": "Full-time",
  "highlights": [
    {
      "text": "Achievement Title",
      "details": "Full description of what you did and the result",
      "tags": ["Standard1", "Standard2", "Domain"],
      "priority": 10
    },
    {
      "text": "Achievement #2",
      "details": "...",
      "tags": ["..."],
      "priority": 9
    }
  ]
}
```

**Tips:**
- **priority**: 10 = most important, 5 = medium, 1 = least important
- **tags**: Use actual standards (ISO 26262, EN 50128, etc.) for auto-filtering
- **current**: true = ongoing role, false = past role
- **highlights**: Usually 2-4 bullet points per job

### Adding a Certification

In the `certifications_qualifications` array:

```json
"certifications_qualifications": [
  "EASA Part 25 Type Certification",
  "ISO 27035 (Incident Response)",
  "FSCAM (Functional Safety Certified Automotive Manager)"
]
```

### Updating Your Headline

```json
"headline": "Your new professional headline here"
```

---

## Git Workflow

### Initial Setup (One-time)

```bash
# Initialize
bash setup-git.sh

# Add everything
git add .
git commit -m "Initial commit: CV management system"
```

### Every Time You Update Data

```bash
# 1. Edit master-cv.json
vim data/master-cv.json

# 2. Regenerate CVs
make generate-all

# 3. Commit
git add data/master-cv.json
git commit -m "Update: [describe what changed]"

# Examples of good commit messages:
# "Add: Valeo ASIL-D ECU certification completion"
# "Update: New role at Capgemini as Principal Consultant"
# "Add: ISO 27035 certification"
# "Update: Polish language level from basic to intermediate"
```

### View Your History

```bash
# See last 10 commits
git log --oneline -10

# See what changed in a specific commit
git show abc1234

# See all changes since last commit
git diff data/master-cv.json
```

---

## 📊 Profile Comparison

Choose the right CV for each job:

| Posting mentions... | Use Profile |
|-------------------|-------------|
| "ISO 26262" or "Functional Safety Manager" | `safety_manager` |
| "Cybersecurity" or "UN R155/R156" or "UNECE" | `cybersecurity` |
| "Type Approval" or "Homologation" or "KBA" | `homologation` |
| "EN 50128" or "Railway" or "EBA/ERA" | `railway` |
| "Director" or "Team Lead" or "Senior Manager" | `leadership` |
| Unsure or mixed | `full` |

---

## Converting to Word/PDF

### Option 1: Copy-Paste (Easiest)

```bash
# View the plain text CV
cat output/CV_DirkGreindl_cybersecurity_en.txt

# Copy the output
# Paste into Microsoft Word or Google Docs
# Adjust formatting as needed
# Save as .docx
```

### Option 2: Pandoc (Advanced)

```bash
# Install Pandoc (if you have brew on Mac)
brew install pandoc

# Convert Markdown to DOCX
pandoc output/CV_DirkGreindl_safety_manager_en.md -o CV_Final.docx
```

---

## Troubleshooting

**"Python command not found"**
```bash
# Try python3 instead
python3 cv_generator.py --profile safety_manager
```

**"make: command not found"**
```bash
# Use Python directly
python3 cv_generator.py --profile safety_manager --output output
```

**"JSON syntax error"**
```bash
# Check your JSON with this online tool:
# https://jsonlint.com/
# Copy data/master-cv.json and paste there
```

**"output/ folder doesn't exist"**
```bash
mkdir -p output
```

---

## Your Next Steps

1. ✅ **Today:** Run `make generate-all` and review the outputs
2. ✅ **This Week:** Initialize Git with `bash setup-git.sh`
3. ✅ **Next Job Search:** Use `make generate-[profile]` for each application
4. ✅ **Whenever You Change:** Update `master-cv.json` → `make generate-all` → `git commit`

---

## Questions?

Ask Claude:
- "Generate a cybersecurity CV for [company]"
- "Update my master-cv.json with [new job/cert]"
- "Show me how to add a new profile type"
- "Help me customize the CV for [specific role]"

---

**Happy Job Hunting! 🎯**

*Your CV system is now automated and Git-tracked. You own your career data.*
