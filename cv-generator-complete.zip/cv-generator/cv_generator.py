#!/usr/bin/env python3
"""
CV Generator for Dirk Greindl
Converts master-cv.json into tailored CV variants based on focus profile
Usage: python cv_generator.py --profile "Safety Manager" --language "en" --format "markdown"
"""

import json
import argparse
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Any

class CVGenerator:
    def __init__(self, master_data_path: str = "data/master-cv.json"):
        """Load master CV data from JSON."""
        with open(master_data_path, 'r', encoding='utf-8') as f:
            self.data = json.load(f)
        
        self.profiles = {
            "safety_manager": {
                "title": "Safety Manager & Certification Expert",
                "focus_standards": ["ISO 26262", "DO-178C", "EN 50128"],
                "weight": {"aerospace": 0.3, "automotive": 0.5, "rail": 0.2}
            },
            "cybersecurity": {
                "title": "Automotive Cybersecurity & Functional Safety Expert",
                "focus_standards": ["ISO/SAE 21434", "UN R155/R156", "ISO 26262"],
                "weight": {"aerospace": 0.2, "automotive": 0.7, "rail": 0.1}
            },
            "homologation": {
                "title": "Homologation & Type Approval Specialist",
                "focus_standards": ["KBA", "UNECE", "EASA", "EBA"],
                "weight": {"aerospace": 0.25, "automotive": 0.4, "rail": 0.35}
            },
            "railway": {
                "title": "Railway Safety Certification Expert",
                "focus_standards": ["EN 50128", "EN 50657", "EBA", "ERA"],
                "weight": {"aerospace": 0.1, "automotive": 0.2, "rail": 0.7}
            },
            "leadership": {
                "title": "Technical Leader & Department Director",
                "focus_standards": ["Team Leadership", "Project Management", "Bid Management"],
                "weight": {"aerospace": 0.4, "automotive": 0.3, "rail": 0.3}
            },
            "full": {
                "title": self.data["headline"],
                "focus_standards": None,
                "weight": {"aerospace": 1.0, "automotive": 1.0, "rail": 1.0}
            }
        }
    
    def filter_experience_by_profile(self, profile: str) -> List[Dict[str, Any]]:
        """Filter and rank experience based on profile focus."""
        if profile == "full":
            return sorted(self.data["experience"], 
                        key=lambda x: x["start_date"], reverse=True)
        
        profile_config = self.profiles.get(profile, self.profiles["full"])
        experience = self.data["experience"].copy()
        
        # Sort by relevance to profile and date
        def score_experience(exp: Dict) -> tuple:
            priority = 0
            for highlight in exp.get("highlights", []):
                tags = highlight.get("tags", [])
                if any(std in highlight["text"] for std in profile_config["focus_standards"]):
                    priority = max(priority, highlight.get("priority", 5))
            
            # Return tuple: (priority descending, date descending)
            return (-priority, -int(exp["start_date"].replace("-", "")))
        
        sorted_exp = sorted(experience, key=score_experience)
        return sorted_exp
    
    def generate_markdown(self, profile: str = "full", language: str = "en") -> str:
        """Generate CV in Markdown format."""
        profile_config = self.profiles.get(profile, self.profiles["full"])
        experience = self.filter_experience_by_profile(profile)
        
        # Build markdown
        md = []
        md.append(f"# {self.data['personal']['name']}")
        md.append(f"\n**{profile_config['title']}**\n")
        md.append(f"Munich, Bavaria | {self.data['personal']['phone']} | {self.data['personal']['email']}")
        md.append(f"LinkedIn: {self.data['personal']['linkedin']}\n")
        
        # Profile
        md.append("## PROFILE\n")
        md.append(self.data["profile_summary"])
        
        # Core Competencies
        md.append("\n## CORE COMPETENCIES\n")
        if profile_config.get("focus_standards"):
            md.append(f"**Focus Areas:** {' · '.join(profile_config['focus_standards'])}\n")
        
        md.append(f"**Certification Standards:** {' · '.join(self.data['competencies']['certification_standards'][:5])}\n")
        md.append(f"**Authorities & Regulators:** {' · '.join(self.data['competencies']['authorities_regulators'][:5])}\n")
        md.append(f"**Technical Domains:** {' · '.join(self.data['competencies']['technical_domains'])}\n")
        md.append(f"**Leadership:** {' · '.join(self.data['competencies']['leadership'])}\n")
        
        # Professional Experience
        md.append("\n## PROFESSIONAL EXPERIENCE\n")
        for exp in experience[:5]:  # Top 5 most relevant
            start = exp["start_date"]
            end = "present" if exp.get("current", False) else exp.get("end_date", "")
            md.append(f"### {exp['title']} | {start} – {end}\n")
            md.append(f"**{exp['company']}** · {exp['location']}\n")
            
            for highlight in sorted(exp.get("highlights", []), 
                                   key=lambda x: x.get("priority", 5), 
                                   reverse=True)[:3]:
                md.append(f"- **{highlight['text']}** — {highlight['details']}\n")
        
        # Education
        md.append("\n## EDUCATION\n")
        for edu in self.data["education"]:
            if "degree" in edu:
                md.append(f"**{edu['degree']}** | {edu.get('institution', '')}\n")
                if edu.get("start_date"):
                    md.append(f"{edu.get('start_date', '')} – {edu.get('end_date', '')}\n")
                if edu.get("thesis"):
                    md.append(f"*Thesis: {edu['thesis']}*\n")
                md.append("")
        
        # Languages & Certifications
        md.append("\n## LANGUAGES & CERTIFICATIONS\n")
        langs = " · ".join([f"{l['language']} ({l['proficiency']})" for l in self.data["languages"]])
        md.append(f"**Languages:** {langs}\n")
        md.append(f"**Certifications:** {' · '.join(self.data.get('certifications_qualifications', []))}\n")
        
        # Footer
        md.append(f"\n---\n*Generated: {datetime.now().strftime('%B %d, %Y')}*\n")
        
        return "\n".join(md)
    
    def generate_plaintext(self, profile: str = "full") -> str:
        """Generate CV in plain text format (ATS-friendly)."""
        profile_config = self.profiles.get(profile, self.profiles["full"])
        experience = self.filter_experience_by_profile(profile)
        
        lines = []
        lines.append(self.data['personal']['name'].upper())
        lines.append(f"\n{profile_config['title']}")
        lines.append(f"\n{self.data['personal']['location']} | {self.data['personal']['phone']} | {self.data['personal']['email']}")
        
        # Profile
        lines.append(f"\nPROFILE\n{self.data['profile_summary']}")
        
        # Core Competencies
        lines.append("\nCORE COMPETENCIES")
        for comp_type, items in self.data['competencies'].items():
            lines.append(f"{comp_type.replace('_', ' ').title()}: {' · '.join(items[:6])}")
        
        # Professional Experience
        lines.append("\nPROFESSIONAL EXPERIENCE\n")
        for exp in experience[:6]:
            start = exp["start_date"]
            end = "present" if exp.get("current", False) else exp.get("end_date", "")
            lines.append(f"{exp['title']} | {start} – {end}")
            lines.append(f"{exp['company']} · {exp['location']}\n")
            
            for highlight in sorted(exp.get("highlights", []), 
                                   key=lambda x: x.get("priority", 5), 
                                   reverse=True)[:3]:
                lines.append(f"- {highlight['text']}: {highlight['details']}")
            lines.append("")
        
        # Education
        lines.append("\nEDUCATION\n")
        for edu in self.data["education"]:
            if "degree" in edu:
                lines.append(f"{edu['degree']} | {edu.get('institution', '')}")
                if edu.get("start_date"):
                    lines.append(f"{edu.get('start_date', '')} – {edu.get('end_date', '')}")
                lines.append("")
        
        # Languages
        lines.append("LANGUAGES")
        for lang in self.data["languages"]:
            lines.append(f"{lang['language']}: {lang['proficiency']}")
        
        lines.append(f"\nGenerated: {datetime.now().strftime('%B %d, %Y')}")
        
        return "\n".join(lines)
    
    def save_cv(self, content: str, filename: str, output_dir: str = "output"):
        """Save CV to file."""
        Path(output_dir).mkdir(exist_ok=True)
        filepath = Path(output_dir) / filename
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)
        print(f"✓ CV saved to {filepath}")
        return filepath


def main():
    parser = argparse.ArgumentParser(description="Generate tailored CVs from master data")
    parser.add_argument("--profile", default="full", 
                       choices=["safety_manager", "cybersecurity", "homologation", "railway", "leadership", "full"],
                       help="CV focus profile")
    parser.add_argument("--language", default="en", choices=["en", "de"],
                       help="Language (en=English, de=German)")
    parser.add_argument("--format", default="markdown", choices=["markdown", "plaintext"],
                       help="Output format")
    parser.add_argument("--output", default="output",
                       help="Output directory")
    
    args = parser.parse_args()
    
    try:
        generator = CVGenerator()
        
        if args.format == "markdown":
            content = generator.generate_markdown(profile=args.profile, language=args.language)
            ext = "md"
        else:
            content = generator.generate_plaintext(profile=args.profile)
            ext = "txt"
        
        filename = f"CV_DirkGreindl_{args.profile}_{args.language}.{ext}"
        generator.save_cv(content, filename, args.output)
        print(f"✓ {args.profile} CV generated successfully!")
        
    except Exception as e:
        print(f"✗ Error: {e}")
        return 1
    
    return 0


if __name__ == "__main__":
    exit(main())
