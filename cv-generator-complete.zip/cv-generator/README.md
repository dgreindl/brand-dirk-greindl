# CV Generator & Management System
**Dirk Greindl's Versioned CV Repository**

---

## 📋 Overview

This is a Git-based CV management system that converts a single **master data source** (`master-cv.json`) into multiple tailored CV variants automatically. No more manual editing of multiple Word documents.

### Features
✅ **Single Source of Truth** – All data in `master-cv.json`  
✅ **Profile-Based Generation** – Auto-tailors CVs for different roles (Safety Manager, Cybersecurity, Homologation, Railway, Leadership)  
✅ **Version Control** – Full Git history of all changes  
✅ **Multiple Formats** – Markdown, Plain Text (ATS-friendly)  
✅ **One Command** – Generate all variants in seconds  

---

## 🏗️ Project Structure

```
cv-generator/
├── data/
│   └── master-cv.json          # Single source of truth (all your data)
├── templates/
│   ├── cv_safety_manager.md    # Template for Safety Manager profile
│   ├── cv_cybersecurity.md     # Template for Cybersecurity profile
│   ├── cv_homologation.md      # Template for Homologation profile
│   └── ...
├── output/
│   └── CV_DirkGreindl_*.md     # Generated CVs (DO NOT edit, regenerate)
├── cv_generator.py             # Main generator script (Python 3.8+)
├── Makefile                    # Quick commands
├── .gitignore                  # Ignore generated files
├── README.md                   # This file
└── .git/                       # Git repository
```

---

## 🚀 Quick Start

### 1. **Initial Setup** (One-time)

```bash
# Initialize Git repository (if not already done)
git init
git config user.name "Dirk Greindl"
git config user.email "dirk.greindl@gmx.net"

# Add all files
git add .
git commit -m "Initial commit: CV management system setup"
```

### 2. **Generate CVs**

```bash
# Generate ALL profiles
python cv_generator.py --profile full --output output

# OR generate specific profiles:
python cv_generator.py --profile safety_manager --output output
python cv_generator.py --profile cybersecurity --output output
python cv_generator.py --profile homologation --output output
python cv_generator.py --profile railway --output output
python cv_generator.py --profile leadership --output output

# With Makefile (easier):
make generate-all        # Generate all profiles
make generate-safety     # Generate specific profile
make generate-cyber
make generate-homologation
make generate-railway
make generate-leadership
```

### 3. **Update Your Data**

Edit `data/master-cv.json` with any changes:
- New job? Add to `experience[]`
- New certification? Add to `certifications_qualifications[]`
- Updated title? Modify `headline`

Then regenerate:
```bash
make generate-all
```

### 4. **Commit Changes**

```bash
git add data/master-cv.json
git commit -m "Update: Add new project X, update certification Y"
git push origin main
```

---

## 📝 Profile Types

| Profile | Focus | Best For |
|---------|-------|----------|
| **safety_manager** | ISO 26262, DO-178C, Certification | Traditional Automotive Safety roles |
| **cybersecurity** | ISO/SAE 21434, UN R155/R156 | Cybersecurity-focused positions |
| **homologation** | KBA, UNECE, Type Approval | Homologation Engineer / Sachverständige roles |
| **railway** | EN 50128, EBA, ERA | Railway certification positions |
| **leadership** | Team Leadership, Project Management | Director / Manager positions |
| **full** | All domains balanced | General applications |

---

## 🔄 Workflow Example

### Scenario: You see a Deloitte Cybersecurity job posting

**Step 1:** Generate cybersecurity-focused CV
```bash
python cv_generator.py --profile cybersecurity --format plaintext --output output
```

**Step 2:** Review output
```
output/CV_DirkGreindl_cybersecurity_en.txt
```

**Step 3:** Customize further (if needed)
- Copy the generated CV
- Adjust minor details for the specific job
- Save as `CV_DirkGreindl_Deloitte_2026-06.docx` (final version for submission)

**Step 4:** Track in Git (optional)
```bash
git add output/CV_DirkGreindl_cybersecurity_en.txt
git commit -m "Generate: Cybersecurity profile for Deloitte application"
```

---

## 📊 JSON Structure (master-cv.json)

### Quick Reference

```json
{
  "personal": {
    "name": "Dirk Greindl",
    "email": "...",
    "phone": "..."
  },
  "experience": [
    {
      "id": "exp_001",
      "title": "Senior Manager",
      "company": "Capgemini",
      "highlights": [
        {
          "text": "Project Title",
          "details": "...",
          "tags": ["ASIL-D", "Homologation"],
          "priority": 10
        }
      ]
    }
  ],
  "competencies": {
    "certification_standards": [...]
  }
}
```

**To add a new job:**
```json
{
  "id": "exp_NEW",
  "title": "New Role Title",
  "company": "Company Name",
  "location": "City",
  "start_date": "2026-01",
  "end_date": null,
  "current": true,
  "highlights": [
    {
      "text": "Achievement #1",
      "details": "Full description",
      "tags": ["TAG1", "TAG2"],
      "priority": 10
    }
  ]
}
```

---

## 🛠️ Commands Reference

```bash
# View all options
python cv_generator.py --help

# Generate specific format
python cv_generator.py --profile cybersecurity --format plaintext
python cv_generator.py --profile safety_manager --format markdown

# View Git log
git log --oneline

# See what changed
git diff data/master-cv.json

# Revert last change
git reset --hard HEAD~1
```

---

## 🎯 Best Practices

### DO ✅
- **Edit only `master-cv.json`** – This is your single source of truth
- **Commit after updates** – Create atomic commits (one change per commit)
- **Use descriptive commit messages** – "Add: Valeo ASIL-D certification" not "Update"
- **Keep highlights in priority order** – Higher priority (10) = more important for CV
- **Tag skills with standards** – Makes filtering easier for specific profiles

### DON'T ❌
- **Edit generated CVs directly** – They're auto-generated; changes will be lost
- **Commit output/ folder** – Git-ignore handles it
- **Store secrets in JSON** – No passwords, API keys, etc.
- **Have outdated data** – Update master-cv.json immediately after job changes

---

## 🔧 Customization

### Add a New Profile

Edit `cv_generator.py` and add to `self.profiles`:

```python
self.profiles = {
    # ... existing profiles ...
    "my_custom_profile": {
        "title": "My Custom Title",
        "focus_standards": ["ISO 26262", "Custom Standard"],
        "weight": {"aerospace": 0.3, "automotive": 0.5, "rail": 0.2}
    }
}
```

Then regenerate:
```bash
python cv_generator.py --profile my_custom_profile
```

---

## 📱 Converting to Word/PDF

### From Markdown to DOCX
```bash
# Using pandoc (install: brew install pandoc)
pandoc output/CV_DirkGreindl_safety_manager_en.md -o CV_Final.docx
```

### From Plain Text to DOCX
```bash
# Copy plain text output and paste into Word
cat output/CV_DirkGreindl_safety_manager_en.txt
```

---

## 🐛 Troubleshooting

**"JSON decode error"**
- Check `master-cv.json` syntax (use https://jsonlint.com/)

**"No such file or directory: data/master-cv.json"**
- Make sure you're in the `cv-generator/` directory
- Check file paths

**"Profile not recognized"**
- Use `python cv_generator.py --help` to see available profiles

---

## 📞 Questions?

For any modifications to the generator or JSON structure, just ask Claude to:
- `Add a new profile type`
- `Update cv_generator.py to include [feature]`
- `Extract data from [job description]`
- `Optimize this CV for [specific role]`

---

## 📄 License & Version History

**Current Version:** v1.0.0  
**Created:** June 16, 2026  
**Last Updated:** June 16, 2026  

### Commit History
```
Initial commit: CV management system setup
```

---

**Built for Dirk Greindl | Senior Expert, Safety Certification & Homologation**
