#!/bin/bash
# Git Setup Script for CV Generator
# Run this once to initialize the Git repository

set -e

echo "🚀 Initializing CV Generator Git Repository"
echo "============================================"
echo ""

# Check if already a git repo
if [ -d ".git" ]; then
    echo "⚠️  Already a Git repository. Skipping init."
    echo ""
else
    echo "📦 Initializing new Git repository..."
    git init
    echo "✓ Git repository created"
    echo ""
fi

# Configure Git user (if not already configured)
if [ -z "$(git config user.name)" ]; then
    echo "⚙️  Configuring Git user..."
    git config user.name "Dirk Greindl"
    git config user.email "dirk.greindl@gmx.net"
    echo "✓ Git user configured"
    echo ""
fi

# Create output directory
if [ ! -d "output" ]; then
    echo "📁 Creating output directory..."
    mkdir -p output
    echo "✓ Output directory created"
fi

echo "📋 Current files to commit:"
git status --short
echo ""

echo "✅ Git setup complete!"
echo ""
echo "Next steps:"
echo "  1. make generate-all        # Generate all CV profiles"
echo "  2. make git-status          # Check status"
echo "  3. git add data/master-cv.json cv_generator.py ..."
echo "  4. git commit -m 'Initial commit: CV management system'"
echo ""
echo "Then whenever you change data/master-cv.json:"
echo "  1. make generate-all        # Regenerate CVs"
echo "  2. git add data/master-cv.json"
echo "  3. git commit -m 'Update: [description of change]'"
echo ""
