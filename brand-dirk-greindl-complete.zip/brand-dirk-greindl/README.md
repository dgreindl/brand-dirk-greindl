# Brand Dirk Greindl – Personal Brand & CV Hub

**Your unified platform for LinkedIn profile management and dynamic CV generation.**

---

## 📋 Quick Start

```bash
cd brand-dirk-greindl

# View LinkedIn profiles
cat linkedin/LINKEDIN_PROFILE_EN.md
cat linkedin/LINKEDIN_PROFILE_DE.md

# View base CVs
cat cv/CV_BASE_EN.md
cat cv/CV_BASE_DE.md

# Generate job-specific CV
# (instructions in jobs/ folder)
```

---

## 📁 Project Structure

```
brand-dirk-greindl/
├── README.md                          # This file
├── linkedin/
│   ├── LINKEDIN_PROFILE_EN.md        # English LinkedIn About + Headlines
│   ├── LINKEDIN_PROFILE_DE.md        # German LinkedIn About + Headlines
│   └── CERTIFICATIONS_FOCUS.md       # Zertifizierungen prominent
├── cv/
│   ├── CV_BASE_EN.md                 # English CV (master)
│   ├── CV_BASE_DE.md                 # German CV (master)
│   └── CV_STRUCTURE.md               # Guide for customization
├── jobs/
│   ├── TEMPLATE.md                   # Job-specific CV template
│   ├── 2026-06_Deloitte_CyberSec.md  # Example: Customized CV
│   └── [company-role].md             # Your job applications
├── data/
│   └── dirk-core-data.json          # Structured data (certifications, experience)
└── .gitignore

```

---

## 🎯 Use Cases

### **1. LinkedIn Profile Management**
Update your LinkedIn using pre-written profiles optimized for your expertise:
- **LINKEDIN_PROFILE_EN.md** – English version (copy-paste to LinkedIn)
- **LINKEDIN_PROFILE_DE.md** – German version (for XING or DE networks)
- **CERTIFICATIONS_FOCUS.md** – Zertifizierungen highlighted

### **2. Dynamic CV Generation**
Tailor your CV for each job application:
1. Copy `jobs/TEMPLATE.md`
2. Name it: `jobs/2026-06_CompanyName_Role.md`
3. Customize for job description
4. Use as CV or convert to DOCX

### **3. Certifications Showcase**
Your certifications are prominently featured in:
- LinkedIn profiles (all versions)
- CV headers
- Job-specific customizations

---

## 🔄 Git Workflow

```bash
# Update LinkedIn profile
vim linkedin/LINKEDIN_PROFILE_EN.md
git add linkedin/
git commit -m "Update: LinkedIn profile with new speaking topic"
git push

# New job application
cp jobs/TEMPLATE.md jobs/2026-06_Deloitte_CyberSec.md
vim jobs/2026-06_Deloitte_CyberSec.md
git add jobs/
git commit -m "New: CV customized for Deloitte Cybersecurity role"
git push
```

---

## 📊 Key Files

| File | Purpose | Update Frequency |
|------|---------|------------------|
| `linkedin/LINKEDIN_PROFILE_EN.md` | English LinkedIn About + Headlines | Quarterly |
| `linkedin/LINKEDIN_PROFILE_DE.md` | German LinkedIn About + Headlines | Quarterly |
| `cv/CV_BASE_EN.md` | Master English CV | When job changes |
| `cv/CV_BASE_DE.md` | Master German CV | When job changes |
| `jobs/[company].md` | Job-specific CV | Per application |
| `data/dirk-core-data.json` | Structured data | When certifications change |

---

## 💡 Tips

- **LinkedIn Headlines:** You have 5 variants – rotate based on audience
- **CVs:** Always start from CV_BASE, customize for role
- **Certifications:** Keep them updated in `dirk-core-data.json`
- **Job Folder:** Every application gets a dated, named file (for future reference)

---

## 📞 Next Steps

1. Review LinkedIn profiles (`linkedin/` folder)
2. Update base CVs if needed (`cv/` folder)
3. When applying for a job: copy & customize from `jobs/TEMPLATE.md`
4. Commit & push to GitHub

---

**Last Updated:** June 16, 2026  
**GitHub:** https://github.com/dgreindl/brand-dirk-greindl
