# Dirk Greindl – Curriculum Vitae (English)

**Senior Expert | Safety Certification & Homologation | Aerospace · Automotive · Rail**

Munich, Bavaria, Germany  
+49 173 132 4544 | dirk.greindl@gmx.net

---

## 🎯 PROFESSIONAL SUMMARY

Safety certification and homologation expert with 20+ years of experience driving complex certification programs to regulatory approval across aviation, automotive, and rail. Deep technical expertise in safety-critical embedded systems combined with OEM, Tier 1, and regulatory stakeholder management. Experienced building and leading cross-functional engineering teams (30–50+ specialists).

**Key Competencies:**
- **Certifications:** ISO 26262 ASIL-D · DO-178C (DAL A/B/C) · ISO/SAE 21434 · UN R155/R156 · EN 50128/50657 · ASPICE
- **Authorities:** EASA · FAA · KBA · UNECE WP.29 · EBA · ERA
- **Domains:** Flight Control Systems · ASIL-D ECU · Rail Safety · Avionics · Homologation & Type Approval

---

## 💼 PROFESSIONAL EXPERIENCE

### **Senior Manager – Intelligent Industry**
**Capgemini Deutschland GmbH** · Munich · Feb 2021 – Present

- **ASIL-D ECU Certification Management:** Tier 1 homologation for KBA/UNECE OEM type approval (target Q4/2027) per ISO 26262, ISO/SAE 21434, UN R155/R156
- **Certification Consulting:** Alstom S-Bahn Rheinland (90 Adessia Stream trains) – EN 50128/50657 framework
- **Model-based Testing (MbT):** Pitch development with technical team (Benedikt Junker, Said Nahari, Alexander Hartmann)
- **Project Acquisition & Bid Management:** Automotive, aviation, and rail sector
- **Knowledge Transfer:** Training on safety-critical system homologation

### **Director of Aerospace – Southern Germany**
**AKKA Germany GmbH** · Munich · Jan 2019 – Jan 2021

- Established and managed Southern Germany Aerospace Department (45+ engineers)
- Technical and managerial leadership; recruiting and skills development
- Tender processing and transnational project implementation

### **Technical Lead & Expert – Software & Electronics**
**Sogeti Deutschland GmbH** · Munich · Jan 2016 – Dec 2018

- Established and scaled SW&E department to 30+ engineers
- **Liebherr Aerospace (Superjet 100):** LRU Lead post-certification (ETOPs 120, Steep Approach, Side Stick Priority). Result: DDP approval EASA 08/2016 & 12/2018
- Technical sales support: RFI evaluation, bid management

### **Head of Operations – ESSEI**
**fortiss GmbH (TU Munich affiliated)** · Munich · May 2014 – Dec 2015

- Established Embedded Systems Software Engineering Institute for aerospace industry-academia cooperation
- Research project management (budget, schedule, quality)
- BDLI (German aerospace association) liaison

### **Senior Electronics Engineer / Technical Development Manager**
**MATIS GROUP Germany** · Munich · Mar 2010 – Apr 2014

- **Airbus A350 CDRC:** DSP software development, DAL A certification with EASA → Type Certificate
- **A400M MCE:** Post-certification (DO-178B DAL A) – Short Circuit Monitor + Explosion Proofness
- **Sukhoi Superjet 100:** Post-certification (DO-178B DAL A/B/C) → EASA European Type Certificate

### **Software Developer / Engineering Consultant**
**2ais Group Limited** · Lenting · Jan 2006 – Feb 2010

- Infotainment system integration, test automation, network management (MOST, CAN, ARINC 429)
- Test process architecture; embedded debugging (QNX)

### **Software Engineer – Real-Time Systems**
**kratzer AUTOMATION** · Unterschleißheim · Sep 2004 – Dec 2005

- Real-time software development (LynxOS/POSIX); device drivers, test data management

---

## 🎓 EDUCATION

**Bachelor of Science in Computer Science**  
Landshut University of Applied Sciences (FH) · Oct 1997 – Apr 2002
- Focus: Technical and Embedded Computer Science
- Thesis: Menu-driven configuration software for LynxOS

**Technical College Entrance Qualification**  
Landshut State Technical High School · Sep 1993 – Jun 1996

**Apprenticeship – Toolmaker / Molding Technologist**  
Dräxlmaier Group · Vilsbiburg · Sep 1989 – Jan 1993

---

## 🏆 CERTIFICATIONS & QUALIFICATIONS

- EASA Part 25 Type Certification
- Airbus Approval Letter (DOID/DTLL)
- FlexRay Certification
- FSCAM (Functional Safety Certified Automotive Manager) – in progress

---

## 🗣️ LANGUAGES

- **German** – Native
- **English** – Business Fluent (C1)
- **Polish** – Basic

---

## 🛠️ TECHNICAL DOMAINS & STANDARDS

**Certification Standards:**  
DO-178C · DO-254 · DO-160 · ARP 4754A · ARP 4761 · ISO 26262:2018 · ISO/SAE 21434 · UN R155/R156 · ASPICE · IATF 16949 · EN 50128/50657

**Bus Systems:**  
ARINC 429 · AFDX · CAN/CAN FD · MOST · FlexRay · Automotive Ethernet

**Leadership Skills:**  
Team Leadership (45+ Engineers) · Bid Management · Audit Leadership · Project Responsibility · Knowledge Transfer

---

## 📍 ADDITIONAL INFORMATION

- **Military Service:** 81st Armored Infantry Battalion · Sep 1996 – Jun 1997
- **Location:** Munich, Bavaria (available for relocation to Poland for extended projects)
- **Interests:** Model-based Testing, Automotive Safety Standards, Railway Certification, Complex Technical Team Leadership

---

**Last Updated:** June 2026  
**Status:** Active (Open to consulting, interim projects, and new challenges)
