# Dirk Greindl – Lebenslauf (Deutsch)

**Senior Expert | Safety Zertifizierung & Homologation | Luftfahrt · Automotive · Bahn**

München, Bayern, Deutschland  
+49 173 132 4544 | dirk.greindl@gmx.net

---

## 🎯 BERUFLICHE ZUSAMMENFASSUNG

Safety-Zertifizierungs- und Homologations-Experte mit 20+ Jahren Erfahrung in komplexen Zertifizierungsprogrammen über Luftfahrt, Automotive und Bahn. Tiefe technische Expertise in sicherheitskritischen eingebetteten Systemen kombiniert mit OEM-, Tier-1- und Behörden-Stakeholder-Management. Erfahrung beim Aufbau und der Leitung von interdisziplinären Ingenieur-Teams (30–50+ Spezialisten).

**Kernkompetenzen:**
- **Zertifizierungen:** ISO 26262 ASIL-D · DO-178C (DAL A/B/C) · ISO/SAE 21434 · UN R155/R156 · EN 50128/50657 · ASPICE
- **Behörden:** EASA · FAA · KBA · UNECE WP.29 · EBA · ERA
- **Domänen:** Flight Control Systeme · ASIL-D ECU · Eisenbahn-Sicherheit · Avionik · Typgenehmigung & Homologation

---

## 💼 BERUFLICHE ERFAHRUNG

### **Senior Manager – Intelligent Industry**
**Capgemini Deutschland GmbH** · München · Feb 2021 – Heute

- **ASIL-D ECU-Zertifizierung:** Tier-1-Homologation für KBA/UNECE OEM-Typgenehmigung (Ziel Q4/2027) gemäß ISO 26262, ISO/SAE 21434, UN R155/R156
- **Zertifizierungs-Consulting:** Alstom S-Bahn Rheinland (90 Adessia Stream Züge) – EN 50128/50657 Rahmenwerk
- **Model-based Testing (MbT):** Pitch-Entwicklung mit technischem Team (Benedikt Junker, Said Nahari, Alexander Hartmann)
- **Projektakquisition & Bid-Management:** Automotive-, Luftfahrt- und Bahnssektor
- **Wissenstransfer:** Schulung zur Zertifizierung sicherheitskritischer Systeme

### **Direktor Aerospace – Süddeutschland**
**AKKA Germany GmbH** · München · Jan 2019 – Jan 2021

- Aufbau und Leitung der Aerospace-Abteilung Süddeutschland (45+ Ingenieure)
- Technische und personelle Führung; Recruiting und Skill-Entwicklung
- Tender-Bearbeitung und internationale Projektumsetung

### **Technical Lead & Expert – Software & Elektronik**
**Sogeti Deutschland GmbH** · München · Jan 2016 – Dez 2018

- Aufbau und Skalierung der SW&E-Abteilung auf 30+ Ingenieure
- **Liebherr Aerospace (Superjet 100):** LRU-Lead Post-Zertifizierung (ETOPs 120, Steep Approach, Side Stick Priority). Ergebnis: DDP-Genehmigung EASA 08/2016 & 12/2018
- Technischer Vertriebsunterstützung: RFI-Evaluierung, Bid-Management

### **Leiter Operationen – ESSEI**
**fortiss GmbH (TU München affiliiert)** · München · Mai 2014 – Dez 2015

- Gründung des Instituts für Embedded Systems Software Engineering für Luft- und Raumfahrtindustrie-Akademie-Kooperation
- Forschungsprojekt-Management (Budget, Zeitplan, Qualität)
- BDLI (Verband der Luftfahrtindustrie) Liaison

### **Senior Elektronik-Ingenieur / Technical Development Manager**
**MATIS GROUP Germany** · München · Mär 2010 – Apr 2014

- **Airbus A350 CDRC:** DSP-Softwareentwicklung, DAL A-Zertifizierung mit EASA → Typzertifikat
- **A400M MCE:** Post-Zertifizierung (DO-178B DAL A) – Short Circuit Monitor + Explosionsschutz
- **Sukhoi Superjet 100:** Post-Zertifizierung (DO-178B DAL A/B/C) → EASA Europäisches Typzertifikat

### **Software-Entwickler / Ingenieur-Berater**
**2ais Group Limited** · Lenting · Jan 2006 – Feb 2010

- Infotainment-System-Integration, Test-Automatisierung, Netzwerk-Management (MOST, CAN, ARINC 429)
- Test-Prozess-Architektur; Embedded-Debugging (QNX)

### **Software-Ingenieur – Real-Time Systeme**
**kratzer AUTOMATION** · Unterschleißheim · Sep 2004 – Dez 2005

- Real-Time-Softwareentwicklung (LynxOS/POSIX); Gerätetreiber, Test-Datenverwaltung

---

## 🎓 AUSBILDUNG

**Bachelor of Science Informatik**  
Hochschule Landshut (FH) · Okt 1997 – Apr 2002
- Schwerpunkt: Technische und Embedded-Informatik
- Diplomarbeit: Menügesteuerte Konfigurationssoftware für LynxOS

**Fachabitur**  
Staatliche Technikerschule Landshut · Sep 1993 – Jun 1996

**Ausbildung – Werkzeugmacher / Spritzguss-Technologe**  
Dräxlmaier Group · Vilsbiburg · Sep 1989 – Jan 1993

---

## 🏆 ZERTIFIZIERUNGEN & QUALIFIKATIONEN

- EASA Part 25 Typzertifizierung
- Airbus Genehmigungsschreiben (DOID/DTLL)
- FlexRay-Zertifizierung
- FSCAM (Functional Safety Certified Automotive Manager) – in Vorbereitung

---

## 🗣️ SPRACHEN

- **Deutsch** – Muttersprache
- **Englisch** – Geschäftsfließend (C1)
- **Polnisch** – Grundlagen

---

## 🛠️ TECHNISCHE DOMÄNEN & NORMEN

**Zertifizierungs-Standards:**  
DO-178C · DO-254 · DO-160 · ARP 4754A · ARP 4761 · ISO 26262:2018 · ISO/SAE 21434 · UN R155/R156 · ASPICE · IATF 16949 · EN 50128/50657

**Bus-Systeme:**  
ARINC 429 · AFDX · CAN/CAN FD · MOST · FlexRay · Automotive Ethernet

**Führungs-Kompetenzen:**  
Team-Leitung (45+ Ingenieure) · Bid-Management · Audit-Leitung · Projekt-Verantwortung · Wissenstransfer

---

## 📍 WEITERE INFORMATIONEN

- **Militärdienst:** 81. Panzergrenadier-Bataillon · Sep 1996 – Jun 1997
- **Standort:** München, Bayern (verfügbar für Umsiedlung nach Polen für längerfristige Projekte)
- **Interessen:** Model-based Testing, Automotive Safety Standards, Eisenbahn-Zertifizierung, Leitung komplexer technischer Teams

---

**Zuletzt aktualisiert:** Juni 2026  
**Status:** Aktiv (offen für Consulting, Interim-Projekte und neue Herausforderungen)
